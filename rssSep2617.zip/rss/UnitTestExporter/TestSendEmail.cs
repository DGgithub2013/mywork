﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using rssFeed.SubscriberService;

namespace UnitTestExporter
{
    [TestClass]
    public class TestSendEmail
    {
        [TestMethod]
        public void TestGetEventsAndSendEmail()
        {
           var pub = new Publisher();
           var result= pub.SendCalenarEvents();
           Assert.IsTrue(result);
        }
    }
}
