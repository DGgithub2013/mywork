﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestExporter
{    [TestClass]
    public class TestTranformExport
    {

        [TestMethod]
        public void TestTransform(){
            var ec = new rssFeed.Exporter.ExporterController("C:\\Temp\\eventSetting.xml");
            bool expected=false;
      
                expected = ec.ReadExportEvents();
           
                Assert.IsTrue(expected);
           
        }
    }
}
