﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;



namespace UnitTestExporter
{
    [TestClass]
    public class TestReadSettings
    {
        [TestMethod]
        public void TestReadXMLSettings()
        {
            var ec = new rssFeed.Exporter.ExporterController("C:\\Temp\\eventSetting.xml");
            var st = ec.ReadSettings();
            string expected = "http://umbraco_cms.vancouver.ca/rss";
            string tested = st.EventsList[0].Url.ToString();
            Assert.AreEqual<string>(tested, expected);
        }
    }
}
