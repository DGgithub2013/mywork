﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using RSSReader;
using VCalendarConverter;
using rssFeed.Exporter;
namespace rssFeed
{
    public partial class TestForm : Form
    {
        private TextBox txtRss;
        private Button btnGetRSS;
        private Button btnGetiCal;
        private TextBox txtiCal;
    
        public TestForm()
        {
            InitializeComponent();
        }
       
        private string covertRss(string url)
        {
            var s = RssReader.Read(url);
            StringBuilder sb = new StringBuilder();
            foreach (RssItem rs in s)
            {
                sb.AppendLine(rs.Title);
                sb.AppendLine(rs.StartDate.ToString());
                sb.AppendLine(rs.EndDate.ToString());
                sb.AppendLine(rs.Link);
                sb.AppendLine(rs.Description);
                sb.AppendLine(rs.Location);
                sb.AppendLine(rs.Subject);
                sb.AppendLine(rs.PublicationDate);
                sb.AppendLine(rs.TimeZoneAdjustment.ToString());
                sb.AppendLine(rs.GUID.ToString());
            }

            return sb.ToString();
        }

  

        private void InitializeComponent()
        {
            this.txtRss = new System.Windows.Forms.TextBox();
            this.txtiCal = new System.Windows.Forms.TextBox();
            this.btnGetRSS = new System.Windows.Forms.Button();
            this.btnGetiCal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtRss
            // 
            this.txtRss.Location = new System.Drawing.Point(55, 83);
            this.txtRss.Multiline = true;
            this.txtRss.Name = "txtRss";
            this.txtRss.Size = new System.Drawing.Size(371, 294);
            this.txtRss.TabIndex = 0;
            // 
            // txtiCal
            // 
            this.txtiCal.Location = new System.Drawing.Point(509, 83);
            this.txtiCal.Multiline = true;
            this.txtiCal.Name = "txtiCal";
            this.txtiCal.Size = new System.Drawing.Size(371, 294);
            this.txtiCal.TabIndex = 1;
            // 
            // btnGetRSS
            // 
            this.btnGetRSS.Location = new System.Drawing.Point(91, 384);
            this.btnGetRSS.Name = "btnGetRSS";
            this.btnGetRSS.Size = new System.Drawing.Size(75, 23);
            this.btnGetRSS.TabIndex = 2;
            this.btnGetRSS.Text = "GetRSS";
            this.btnGetRSS.UseVisualStyleBackColor = true;
            this.btnGetRSS.Click += new System.EventHandler(this.btnGetRSS_Click);
            // 
            // btnGetiCal
            // 
            this.btnGetiCal.Location = new System.Drawing.Point(794, 399);
            this.btnGetiCal.Name = "btnGetiCal";
            this.btnGetiCal.Size = new System.Drawing.Size(75, 23);
            this.btnGetiCal.TabIndex = 3;
            this.btnGetiCal.Text = "GetiCal";
            this.btnGetiCal.UseVisualStyleBackColor = true;
            this.btnGetiCal.Click += new System.EventHandler(this.btnGetiCal_Click);
            // 
            // TestForm
            // 
            this.ClientSize = new System.Drawing.Size(939, 470);
            this.Controls.Add(this.btnGetiCal);
            this.Controls.Add(this.btnGetRSS);
            this.Controls.Add(this.txtiCal);
            this.Controls.Add(this.txtRss);
            this.Name = "TestForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        private void Convert(object sender, EventArgs e)
        {
         

     
        }


        private void btnGetRSS_Click(object sender, EventArgs e)
        {
            string url = "http://umbraco_cms.vancouver.ca/rss";
            var readableRss = covertRss(url);

         txtRss.Text = readableRss;
        }

        private void btnGetiCal_Click(object sender, EventArgs e)
        {
            var settingspath = AppDomain.CurrentDomain.BaseDirectory;
            var ec = new rssFeed.Exporter.ExporterController(settingspath + "Resources\\eventSetting.xml");
           // bool expected =ec.ReadExportEvents();   
            string url = "http://umbraco_cms.vancouver.ca/rss";
            // var readableRss = covertRss(url);
            var icals = ec.ConvertiCal(url);
            var icalcontroller = new VCalendarControler();
            var radeableical = icalcontroller.GetICalendar(icals.VCalendarItemList[0]);
            // txtTitle.Text = readableRss;
            this.txtiCal.Text = radeableical;
        }

  
   

    }






}
