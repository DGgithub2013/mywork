﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestExporter
{
    [TestClass]
    public class TestExport
    {
     
        public void TestExportFile(string strExportfile)
        {
        }
    }
}
