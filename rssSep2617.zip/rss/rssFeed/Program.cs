﻿using rssFeed.SubscriberService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace rssFeed
{
    static class Program
    {
     
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
      {
        //Application.EnableVisualStyles();
       // Application.SetCompatibleTextRenderingDefault(false);
      
    // Application.Run(new Batch());
       // Application.Run(new TestForm());
          GetFeed();
      }

        private static void GetFeed() {

            var settingspath = AppDomain.CurrentDomain.BaseDirectory;
            var ec = new rssFeed.Exporter.ExporterController(settingspath + "Resources\\eventSetting.xml");
            bool expected = false;

            expected = ec.ReadExportEvents();   
        }
    

    }

}
