﻿namespace rssFeed
{
    partial class TestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.btnGetFeed = new System.Windows.Forms.Button();
            this.btnConvert = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtiCal
            // 
            this.txtiCal.Location = new System.Drawing.Point(15, 12);
            this.txtiCal.Multiline = true;
            this.txtiCal.Name = "txtiCal";
            this.txtiCal.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtiCal.Size = new System.Drawing.Size(834, 257);
            this.txtiCal.TabIndex = 0;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(15, 12);
            this.txtTitle.Multiline = true;
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtTitle.Size = new System.Drawing.Size(834, 257);
            this.txtTitle.TabIndex = 0;
            // 
            // btnGetFeed
            // 
            this.btnGetFeed.Location = new System.Drawing.Point(258, 288);
            this.btnGetFeed.Name = "btnGetFeed";
            this.btnGetFeed.Size = new System.Drawing.Size(144, 23);
            this.btnGetFeed.TabIndex = 1;
            this.btnGetFeed.Text = " First get rss feed";
            this.btnGetFeed.UseVisualStyleBackColor = true;
            this.btnGetFeed.Click += new System.EventHandler(this.btnGetFeed_Click);
   
            // 
            // TestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 340);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.btnGetFeed);
            this.Controls.Add(this.txtTitle);
            this.Name = "TestForm";
            this.Text = " Test Display";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtiCal;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Button btnGetFeed;
        private System.Windows.Forms.Button btnConvert;
    }
}

