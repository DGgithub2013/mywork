﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using rssFeed.SubscriberService;

namespace UnitTestExporter
{
    [TestClass]
    public class TestGetSubscriberEmail
    {
        [TestMethod]
        public void TestGetEmail()
        {
            var pub= new Publisher();
            var email = pub.GetToMail();
            Assert.IsTrue(email.Equals("dganea@yahoo.com"));
        }
    }
}
