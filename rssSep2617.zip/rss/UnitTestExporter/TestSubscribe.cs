﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using rssFeed.SubscriberService;

namespace UnitTestExporter
{
    [TestClass]
    public class TestSubscribe
    {
        [TestMethod]
        public void TestAddSubscriber()
        {
            Account newacc = new Account("Dy", "dganea@yahoo.com");
            Subscriber sub = new Subscriber();
            var result=  sub.Subscribe(newacc.Email, newacc.Name);
            Assert.IsTrue(result.Equals("created"));
        }
    }
}
